package com.example.quizn;

public class Question {
    private int QuestionId;
    private boolean Answer;
    public Question(int questionId,boolean AAnswer){
        this.QuestionId=questionId;
        this.Answer=AAnswer;

    }

    public boolean isTrueAnswer() {


        return Answer;
    }
    public int getQuestionId(){
        return QuestionId;
    }
}
